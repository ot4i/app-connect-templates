To refer to these instructions while editing the flow, open [the github page](Sync%20new%20attendee%20from%20Eventbrite%20to%20lead%20in%20Insightly_instructions.md) (opens in a new window).

1.	Click **Create flow** to start using the template.
2.	Connect to the following accounts by using your credentials:
    - **Eventbrite** 
	- **Insightly**
3.	To start the flow, in the banner, open the options menu [⋮] and click **Start flow**.

The flow is started when a new attendee is created in Eventbrite.