To refer to these instructions while editing the flow, open [the github page](Create%20a%20new%20Jira%20issue%20for%20a%20new%20Trello%20card_instructions.md) (opens in a new window).

1.	Click **Create flow** to start using the template.
2.	Click Jira / **New issue**.
3.	Connect to [**Jira** ](https://ibm.biz/ach2jira) and then select the project that you want to use.
4.	Click Trello / **Add card to list**.
5.	Connect to [**Trello**](https://ibm.biz/actrello) and then select a preferred team, board, and list from your Trello account
6.	To start the flow, in the banner open the options menu [⋮] and click **Start flow**.

The flow is triggered when a new issue is created in Jira.

## Testing the Flow

In Jira, create a new issue.  A new card will be created in Trello with the Jira issue id as the name
