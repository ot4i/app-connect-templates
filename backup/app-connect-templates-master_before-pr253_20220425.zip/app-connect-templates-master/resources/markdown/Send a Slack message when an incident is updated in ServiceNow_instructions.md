To refer to these instructions while editing the flow, open [the github page](Send%20a%20Slack%20message%20when%20an%20incident%20is%20updated%20in%20ServiceNow_instructions.md) (opens in a new window).

1.	Click **Create flow** to start using the template.
2.	Connect to the following accounts by using your credentials:
    - **ServiceNow** 
    - **Slack**
3.	To start the flow, in the banner, open the options menu [⋮] and click **Start flow**.

The flow is started when an incident is updated in ServiceNow.
