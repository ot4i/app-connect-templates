To refer to these instructions while editing the flow, open [the github page](Creates%20a%20Dropbox%20folder%20and%20shares%20the%20link%20via%20Slack%20when%20a%20new%20spreadsheet%20is%20created%20in%20Google%20Sheets_instructions.md) (opens in a new window).

1.	Click **Create flow** to start using the template.
2.	Connect to the following accounts by using your credentials:
    - **Goolge Sheets** 
    - **Dropbox**
    - **Slack**
3.  Select a preferred spreadsheet and worksheet from your Google Sheets account.
4.	To start the flow, in the banner, open the options menu [⋮] and click **Start flow**.

The flow is started when a new spreadsheet is created in Google Sheets.
