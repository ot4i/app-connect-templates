To refer to these instructions while editing the flow, open [the github page](https://github.com/ot4i/app-connect-templates/blob/master/resources/markdown/Send%20me%20a%20Slack%20notification%20for%20every%20new%20Insightly%20contact_instructions.md) (opens in a new window).

1. Click **Create flow** to start using the template.
1. Connect to your [Insightly account](https://developer.ibm.com/integration/docs/app-connect/how-to-guides-for-apps/use-ibm-app-connect-insightly/).
1. Connect to your [Slack account](https://developer.ibm.com/integration/docs/app-connect/how-to-guides-for-apps/use-ibm-app-connect-slack/) and choose the channel that you want to post the message to.                                          
1. To start the flow, in the banner open the options menu [&#8942;] then click **Start flow**.
