To refer to these instructions while editing the flow, open [the github page](Creates%20a%20file%20in%20Dropbox%20when%20a%20new%20email%20is%20received%20in%20Gmail_instructions.md) (opens in a new window).

1.	Click **Create flow** to start using the template.
2.	Connect to the following accounts by using your credentials:
    - **Gmail** 
	- **Dropbox**
3.	To start the flow, in the banner, open the options menu [⋮] and click **Start flow**.

The flow is started when a new email is received in Gmail.