To refer to these instructions while editing the flow, open [the github page](https://github.com/ot4i/app-connect-templates/tree/master/resources/markdown/Sync%20new%20attendee%20from%20Eventbrite%20to%20lead%20in%20Microsoft%20Dynamics%20365_instructions.md) (opens in a new window).

1.	Click **Create flow** to start using the template.
2.	Connect to the following accounts by using your credentials:
    - **Eventbrite**
    - **Microsoft Dynamics 365 for Sales** 
3.	To start the flow, in the banner, open the options menu [⋮] and click **Start flow**.

The flow is started when a new attendee is created in Eventbrite.
