To refer to these instructions while editing the flow, open [the github page](Sync%20new%20contact%20from%20Insightly%20to%20Marketo_instructions.md) (opens in a new window).

1.	Click **Create flow** to start using the template.
2.	Connect to the following accounts by using your credentials:
    - **Insightly** 
	- **Marketo**
	- **Slack**
3.	To start the flow, in the banner, open the options menu [⋮] and click **Start flow**.

The flow is started when a new contact is created in Insightly.