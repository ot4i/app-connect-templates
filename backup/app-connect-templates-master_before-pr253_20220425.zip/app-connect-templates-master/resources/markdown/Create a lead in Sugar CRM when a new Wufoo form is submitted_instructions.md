To refer to these instructions while editing the flow, open [the github page](https://github.com/ot4i/app-connect-templates/blob/master/resources/markdown/Create%20a%20lead%20in%20Sugar%20CRM%20when%20a%20new%20Wufoo%20form%20is%20submitted_instructions.md) (opens in a new window).

1. Ensure that the Wufoo form you are using includes a **First name** and **Last name** field.
1. Click **Create flow** to start using the template.
1. Connect to your [Wufoo account](https://developer.ibm.com/integration/docs/app-connect/how-to-guides-for-apps/use-ibm-app-connect-wufoo/).
1. Connect to your [Sugar CRM account] (https://developer.ibm.com/integration/docs/app-connect/how-to-guides-for-apps/use-ibm-app-connect-sugarcrm/).
1. To start the flow, in the banner open the options menu [&#8942;] then click **Start flow**.
