To refer to these instructions while editing the flow, open [the github page](https://github.com/ot4i/app-connect-templates/blob/master/resources/markdown/Create%20an%20Asana%20task%20from%20a%20Gmail%20message_instructions.md) (opens in a new window).

1. Click **Create flow** to start using the template.
1. Connect to your [Gmail account](http://ibm.biz/acgmail).
1. Connect to your [Asana account](http://ibm.biz/acasana).
1. Click the Asana node and update the Project field with your Project name.
1. To start the flow, in the banner open the options menu [&#8942;] then click **Start flow**.
