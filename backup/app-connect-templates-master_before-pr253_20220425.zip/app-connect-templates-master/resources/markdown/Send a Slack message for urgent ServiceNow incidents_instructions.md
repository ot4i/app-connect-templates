1. Click **Create flow** to start using the template.
2. Connect to your [ServiceNow account](http://ibm.biz/acservicenow).
3. Connect to your [Slack account](http://ibm.biz/acslack) and edit the message location and content to meet your business needs.
4. To start the flow, in the banner open the options menu [&#8942;] then click **Start flow**.
