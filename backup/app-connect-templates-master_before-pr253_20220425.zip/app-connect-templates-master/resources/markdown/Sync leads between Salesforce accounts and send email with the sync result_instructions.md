To refer to these instructions while editing the flow, open [the github page](https://github.com/ot4i/app-connect-templates/blob/master/resources/markdown/Sync%20leads%20between%20Salesforce%20accounts%20and%20send%20email%20with%20the%20sync%20result_instructions.md) (opens in a new window).

1. Click **Create flow** to start using the template.
1. Connect to your [Slack account](http://ibm.biz/acslack).
1. Click on each **Slack** node and choose the channel that you want to post the message to.
1. Connect to your [Salesforce accounts](http://ibm.biz/ach2salesforce).
1. Connect to your [Gmail account](http://ibm.biz/acgmail).
1. Click on each **Gmail** node and update the **To** field with a valid email address.
1. To start the flow, in the banner open the options menu [&#8942;] then click **Start flow**.
