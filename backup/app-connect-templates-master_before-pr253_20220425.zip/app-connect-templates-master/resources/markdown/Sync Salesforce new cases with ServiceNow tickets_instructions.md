To refer to these instructions while editing the flow, open [the github page](https://github.com/ot4i/app-connect-templates/blob/master/resources/markdown/Sync%20Salesforce%20new%20cases%20with%20ServiceNow%20tickets_instructions.md) (opens in a new window).

1. Click **Create flow** to start using the template.
1. Connect to your [Salesforce account](https://developer.ibm.com/integration/docs/app-connect/how-to-guides-for-apps/use-ibm-app-connect-salesforce/).   
1. Connect to your [ServiceNow account](https://developer.ibm.com/integration/docs/app-connect/how-to-guides-for-apps/use-ibm-app-connect-servicenow/).
1. To start the flow, in the banner open the options menu [&#8942;] then click **Start flow**.
