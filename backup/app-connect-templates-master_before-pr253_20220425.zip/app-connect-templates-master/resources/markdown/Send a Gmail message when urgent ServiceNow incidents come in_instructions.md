To refer to these instructions while editing the flow, open [the github page](https://github.com/ot4i/app-connect-templates/blob/master/resources/markdown/Send%20a%20Gmail%20message%20when%20urgent%20ServiceNow%20incidents%20come%20in_instructions.md) (opens in a new window).

1. Click **Create flow** to start using the template.
1. Connect to your [ServiceNow account](http://ibm.biz/acservicenow).
1. Connect to your [Gmail account](http://ibm.biz/acgmail) and edit the email subject and body to meet your business needs.
1. To start the flow, in the banner open the options menu [&#8942;] then click **Start flow**.
