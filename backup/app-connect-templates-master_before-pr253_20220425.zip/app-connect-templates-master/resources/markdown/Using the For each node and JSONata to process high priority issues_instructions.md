To refer to these instructions while editing the flow, open [the github page](https://github.com/ot4i/app-connect-templates/blob/master/resources/markdown/Using%20the%20For%20each%20node%20and%20JSONata%20to%20process%20high%20priority%20issues_instructions.md) (opens in a new window).

1. Click **Create flow** to start using the template.
1. Connect to your Atlassian Jira Service Desk account.
1. (Optional) Update any fields to match the data you want to capture.
1. To start the flow, in the banner open the options menu [&#8942;] then click **Start flow**.
