To refer to these instructions while editing the flow, open [the github page](https://github.com/ot4i/app-connect-templates/blob/master/resources/markdown/Send%20Gmail%20message%20to%20new%20Salesforce%20lead_instructions.md) (opens in a new window).

1. Click **Create flow** to start using the template.
1. Connect to your [Salesforce account](http://ibm.biz/ach2salesforce).
1. Connect to your [Gmail account](http://ibm.biz/acgmail) and update the email subject and body to meet your business needs.
1. To start the flow, in the banner open the options menu [&#8942;] then click **Start flow**.
