To refer to these instructions while editing the flow, open [the github page](Retrieve%20MS%20Dynamics%20365%20leads%20and%20create%20an%20MS%20Excel%20CSV%20file%20in%20Dropbox%20at%20regular%20intervals_instructions.md) (opens in a new window).

1.	Click **Create flow** to start using the template.
2.	Connect to the following accounts by using your credentials:
    - **Microsoft Dynamics 365 for Sales**
	- **Dropbox**
3.	To start the flow, in the banner, open the options menu [⋮] and click **Start flow**.

The flow is scheduled to trigger once a day at 00:00 UTC.  
