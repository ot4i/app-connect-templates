To refer to these instructions while editing the flow, open [the github page](https://github.com/ot4i/app-connect-templates/tree/master/resources/markdown/Record%20SugarCRM%20campaign%20to%20Google%20Sheets_instructions.md) (opens in a new window).

1.	Click **Create flow** to start using the template.
2.	Connect to the following accounts by using your credentials:
    -	**SugarCRM** 
    - **Google Sheets**
3.  Select a preferred spreadsheet and worksheet from your Google Sheets account.
4.	To start the flow, in the banner, open the options menu [⋮] and click **Start flow**.

The flow is started when a new campaign is created in SugarCRM.
