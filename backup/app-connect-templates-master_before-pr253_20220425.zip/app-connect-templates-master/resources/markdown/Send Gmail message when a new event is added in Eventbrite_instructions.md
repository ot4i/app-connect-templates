To refer to these instructions while editing the flow, open [the github page](https://github.com/ot4i/app-connect-templates/blob/master/resources/markdown/Send%20Gmail%20message%20when%20a%20new%20event%20is%20added%20in%20Eventbrite_instructions.md) (opens in a new window).

1. Click **Create flow** to start using the template.
1. Connect to your [Eventbrite account](http://ibm.biz/aceventbrite).
1. Connect to your [Gmail account](http://ibm.biz/acgmail) and update the email subject and body to meet your business needs.
1. To start the flow, in the banner open the options menu [&#8942;] then click **Start flow**.
