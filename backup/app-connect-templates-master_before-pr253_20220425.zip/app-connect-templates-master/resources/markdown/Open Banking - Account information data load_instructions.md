To refer to these instructions while editing the flow, open [the github page](https://github.com/ot4i/app-connect-templates/blob/master/resources/markdown/Open%20Banking%20-%20Account%20information%20data%20load_instructions.md) (opens in a new window).

1. Click **Create flow** to start using the template.
1. Connect to your Yapily account.
1. For each IBM Cloudant action, connect to your [IBM Cloudant account](https://developer.ibm.com/integration/docs/app-connect/how-to-guides-for-apps/use-ibm-app-connect-ibm-cloudant/) and select the database for the document to be created or updated.
1. To start the flow, in the banner open the options menu [&#8942;] then click **Start flow**.
