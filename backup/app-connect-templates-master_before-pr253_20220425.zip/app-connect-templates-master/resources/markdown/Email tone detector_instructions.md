To refer to these instructions while editing the flow, open [the github page](https://github.com/ot4i/app-connect-templates/blob/master/resources/markdown/Email%20tone%20detector_instructions.md) (opens in a new window).

1. Click **Create flow** to start using the template.
1. Connect to your [Gmail account](http://ibm.biz/acgmail).
1.	Connect to your [Watson Tone Analyzer account](http://ibm.biz/acwatsontonea).
1.	Click the **Situation detector** node and update the fields according to your business needs.
1.	Connect to your [Slack account](http://ibm.biz/acslack).
1. For the Slack "Create message" action select the channel that you want to post your message to.
1. To start the flow, in the banner open the options menu [&#8942;] then click **Start flow**.
