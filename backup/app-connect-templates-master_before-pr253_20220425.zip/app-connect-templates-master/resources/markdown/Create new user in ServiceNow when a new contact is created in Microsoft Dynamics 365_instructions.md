To refer to these instructions while editing the flow, open [the github page](https://github.com/ot4i/app-connect-templates/tree/master/resources/markdown/Create%20a%20new%20user%20in%20ServiceNow%20when%20a%20new%20case%20is%20created%20in%20Microsoft%20Dynamics_instructions.md) (opens in a new window).

1.	Click **Create flow** to start using the template.
2.	Connect to the following accounts by using your credentials:
    -	**Microsoft Dynamics 365 for Sales** 
    - **ServiceNow**
3.	To start the flow, in the banner, open the options menu [⋮] and click **Start flow**.

The flow is started when a new case is created in Microsoft Dynamics 365 for Sales.
