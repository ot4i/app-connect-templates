To refer to these instructions while editing the flow, open [the github page](https://github.com/ot4i/app-connect-templates/blob/master/resources/markdown/Creating%20targeted%20contact%20lists%20based%20on%20unconverted%20leads%20and%20geography_instructions.md) (opens in a new window).

1. Click **Create flow** to start using the template.
1. Connect to your [Eventbrite account](https://developer.ibm.com/integration/docs/app-connect/how-to-guides-for-apps/use-ibm-app-connect-eventbrite/).
1. Connect to your [Salesforce account](https://developer.ibm.com/integration/docs/app-connect/how-to-guides-for-apps/use-ibm-app-connect-salesforce/).
1. Connect to your [Slack account](https://developer.ibm.com/integration/docs/app-connect/how-to-guides-for-apps/use-ibm-app-connect-slack/).
1. To start the flow, in the banner open the options menu [&#8942;] then click **Start flow**.
