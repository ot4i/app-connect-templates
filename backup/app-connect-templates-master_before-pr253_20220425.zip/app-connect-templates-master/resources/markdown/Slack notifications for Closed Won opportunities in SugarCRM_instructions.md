To refer to these instructions while editing the flow, open [the github page](https://github.com/ot4i/app-connect-templates/tree/master/resources/markdown/Slack%20notifications%20for%20Closed%20Won%20opportunities%20in%20SugarCRM_instructions.md) (opens in a new window).

1.	Click **Create flow** to start using the template.
2.	Connect to the following accounts by using your credentials:
    - **SugarCRM** 
    - **Slack**
3.	To start the flow, in the banner, open the options menu [⋮] and click **Start flow**.

The flow is started when an opportunity is updated to 'Closed Won' status in SugarCRM.
