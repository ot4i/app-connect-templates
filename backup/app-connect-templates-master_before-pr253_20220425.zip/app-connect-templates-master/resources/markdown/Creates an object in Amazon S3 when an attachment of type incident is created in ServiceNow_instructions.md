To refer to these instructions while editing the flow, open [the github page](Creates%20an%20object%20in%20Amazon%20S3%20when%20an%20attachment%20of%20type%20incident%20is%20created%20in%20ServiceNow_instructions.md) (opens in a new window).

1.	Click **Create flow** to start using the template.
2.	Connect to the following accounts by using your credentials:
      - **ServiceNow** 
      - **Amazon S3**
3.	To start the flow, in the banner, open the options menu [⋮] and click **Start flow**.

The flow is started when a new attachment is created in ServiceNow.
