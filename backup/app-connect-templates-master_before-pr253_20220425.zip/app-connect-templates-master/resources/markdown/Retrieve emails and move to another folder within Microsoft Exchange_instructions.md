To refer to these instructions while editing the flow, open [the github page](Creates%20an%20Asana%20task%20when%20a%20new%20Microsoft%20Teams%20message%20is%20created_instructions.md) (opens in a new window).

1.	Click **Create flow** to start using the template.
2.	Connect to the following accounts by using your credentials:
    - **Microsoft Exchange** 
3.	To start the flow, in the banner, open the options menu [⋮] and click **Start flow**.

You can invoke the API call by using the Postman application. In the Postman application, you must provide the email URL with the parent folder ID, source and destination values.