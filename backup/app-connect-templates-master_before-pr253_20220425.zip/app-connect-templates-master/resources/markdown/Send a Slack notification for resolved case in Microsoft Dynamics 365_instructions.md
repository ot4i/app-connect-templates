To refer to these instructions while editing the flow, open [the github page](Send%20a%20Slack%20notification%20for%20resolved%20case%20in%20Microsoft%20Dynamics%20365_instructions.md) (opens in a new window).

1.	Click **Create flow** to start using the template.
2.	Connect to the following accounts by using your credentials:
    - **Microsoft Dynamics 365 for Sales** 
	- **Slack**
3.	To start the flow, in the banner, open the options menu [⋮] and click **Start flow**.

The flow is started when a case is updated to 'resolved' in Microsoft Dynamics 365 for Sales.