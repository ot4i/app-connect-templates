To refer to these instructions while editing the flow, open [the github page](https://github.com/ot4i/app-connect-templates/blob/master/resources/markdown/Post%20Slack%20message%20for%20new%20Gmail%20message_instructions.md) (opens in a new window).

1. Click **Create flow** to start using the template.
1. Connect to your [Gmail account](https://developer.ibm.com/integration/docs/app-connect/how-to-guides-for-apps/use-ibm-app-connect-gmail/).
1. Connect to your [Slack account](https://developer.ibm.com/integration/docs/app-connect/how-to-guides-for-apps/use-ibm-app-connect-slack/).
1. Click the Slack node and and choose the Slack channels where you'd like to post your messages.  You can also change the text of the message if you want to..
1. To start the flow, in the banner open the options menu [&#8942;] then click **Start flow**.
