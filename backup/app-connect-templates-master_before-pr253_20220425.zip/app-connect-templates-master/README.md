# app-connect-templates
This repo contains flow templates for [IBM App Connect](https://appconnect.ibmcloud.com/)
